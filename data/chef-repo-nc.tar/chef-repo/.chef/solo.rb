file_cache_path "/tmp/chef-solo"
cookbook_path "/root/chef-repo/cookbooks"
role_path "/path/to/roles"
log_level :debug
